"""
app.py - Smart Water Consumption Monitoring and Demand Forecasting System
=========================================================================
Run with:   streamlit run app.py

The dashboard reads the Pune Household Survey CSV (survey data, NOT real-time
smart-meter readings) and shows analytics, potential anomalies and a simple
monthly demand-forecasting experiment.
"""

import html
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import streamlit as st

from modules import analysis, data_processing as dp, forecasting as fc, visualization as viz

APP_DIR = Path(__file__).parent
DATA_PATH = APP_DIR / "data" / dp.DATA_FILE_NAME

st.set_page_config(page_title="Smart Water Monitoring", page_icon="💧", layout="wide")

# --------------------------------------------------------------------------
# Styling (blue / white water theme)
# --------------------------------------------------------------------------
st.markdown(
    """
    <style>
    :root {--navy:#08306B; --blue:#1D70A2; --sky:#4A9FD1; --mist:#E6F1FA; --ink:#16324F; --muted:#5B7690;}
    .stApp {background: linear-gradient(180deg, #EAF4FC 0%, #F7FBFE 320px, #FFFFFF 100%);}
    .block-container {padding-top: 1.4rem; max-width: 1280px;}

    /* Text: always dark ink on light surfaces, whatever the OS theme is */
    .stApp, .stApp p, .stApp li, .stApp label, .stApp span, .stApp div[data-testid="stCaptionContainer"],
    [data-testid="stWidgetLabel"] p, [data-testid="stMarkdownContainer"] {color: var(--ink);}
    .stApp h1, .stApp h2, .stApp h3, .stApp h4 {color: var(--navy) !important; letter-spacing: -0.01em;}
    [data-testid="stCaptionContainer"] p {color: var(--muted) !important;}

    /* Sidebar */
    [data-testid="stSidebar"] {background: linear-gradient(180deg, #DCEBF8 0%, #EEF6FC 100%);
                               border-right: 1px solid #C9DFF1;}
    [data-testid="stSidebar"] * {color: var(--ink);}
    [data-testid="stSidebar"] h2 {color: var(--navy) !important;}
    [data-testid="stSidebar"] [role="radiogroup"] label {background: white; border: 1px solid #CFE3F4;
        border-radius: 10px; padding: .45rem .7rem; margin-bottom: .3rem; width: 100%;
        transition: all .15s ease;}
    [data-testid="stSidebar"] [role="radiogroup"] label:hover {border-color: var(--sky); transform: translateX(2px);}
    [data-testid="stSidebar"] [role="radiogroup"] label:has(input:checked) {
        background: linear-gradient(90deg, #08306B, #1D70A2); border-color: #08306B;}
    [data-testid="stSidebar"] [role="radiogroup"] label:has(input:checked) * {color: white !important;}

    /* Hero banner */
    .hero {position: relative; overflow: hidden; color: white;
           background: linear-gradient(120deg, #052A5E 0%, #1D70A2 55%, #5BB2E0 100%);
           padding: 1.5rem 1.8rem; border-radius: 18px; margin-bottom: 1.1rem;
           box-shadow: 0 10px 28px rgba(8,48,107,.22);}
    .hero:before {content: ""; position: absolute; right: -60px; top: -80px; width: 260px; height: 260px;
                  border-radius: 50%; background: rgba(255,255,255,.10);}
    .hero:after {content: ""; position: absolute; right: 120px; bottom: -110px; width: 220px; height: 220px;
                 border-radius: 50%; background: rgba(255,255,255,.07);}
    .hero, .hero * {color: white !important;}
    .hero h1 {margin: 0; font-size: 1.9rem; font-weight: 800; position: relative; z-index: 1;}
    .hero p {margin: .35rem 0 .7rem 0; opacity: .94; position: relative; z-index: 1;}
    .badge {display: inline-block; background: rgba(255,255,255,.18); border: 1px solid rgba(255,255,255,.35);
            padding: .15rem .65rem; border-radius: 999px; font-size: .78rem; margin-right: .4rem;
            position: relative; z-index: 1;}

    /* Section headers */
    .section-title {margin: .2rem 0 .9rem 0; padding-bottom: .5rem; border-bottom: 3px solid #CFE3F4;}
    .section-title h2 {margin: 0; font-size: 1.55rem; color: var(--navy) !important;}
    .section-title p {margin: .15rem 0 0 0; color: var(--muted) !important; font-size: .92rem;}

    /* KPI cards */
    .kpi {display: flex; gap: .8rem; align-items: center; background: white; border: 1px solid #D6EAF8;
          border-radius: 16px; padding: .9rem 1rem; min-height: 118px;
          box-shadow: 0 4px 14px rgba(8,48,107,.08); transition: transform .15s ease, box-shadow .15s ease;}
    .kpi:hover {transform: translateY(-3px); box-shadow: 0 10px 22px rgba(8,48,107,.15);}
    .kpi-icon {flex: 0 0 46px; height: 46px; border-radius: 14px; display: flex; align-items: center;
               justify-content: center; font-size: 1.4rem; background: linear-gradient(135deg, #DDEEFA, #B9DBF2);}
    .kpi-body {min-width: 0;}
    .kpi-title {color: var(--muted) !important; font-size: .72rem; text-transform: uppercase;
                letter-spacing: .06em; font-weight: 600;}
    .kpi-value {color: var(--navy) !important; font-size: 1.45rem; font-weight: 800; line-height: 1.25;
                overflow-wrap: anywhere;}
    .kpi-sub {color: var(--muted) !important; font-size: .78rem;}

    /* Callouts */
    .note {background: #FFF6E9; border: 1px solid #F8D9A8; border-left: 6px solid #F28E2B;
           padding: .8rem 1.1rem; border-radius: 12px; color: #5A3A10 !important; font-size: .92rem;}
    .note * {color: #5A3A10 !important;}
    .info {background: #EAF4FC; border: 1px solid #C9E0F2; border-left: 6px solid #1D70A2;
           padding: .8rem 1.1rem; border-radius: 12px; color: var(--ink) !important; font-size: .92rem;}
    .info * {color: var(--ink) !important;}

    /* Tabs as pills */
    .stTabs [data-baseweb="tab-list"] {gap: .4rem; border-bottom: none; flex-wrap: wrap;}
    .stTabs button[role="tab"] {background: white; border: 1px solid #CFE3F4; border-radius: 999px;
                                padding: .35rem 1rem; height: auto;}
    .stTabs button[role="tab"] p {font-weight: 600; font-size: .9rem;}
    .stTabs button[role="tab"][aria-selected="true"] {background: linear-gradient(90deg, #08306B, #1D70A2);
                                                      border-color: #08306B;}
    .stTabs button[role="tab"][aria-selected="true"] p {color: white !important;}
    .stTabs [data-baseweb="tab-highlight"], .stTabs [data-baseweb="tab-border"] {display: none;}

    /* Charts and tables sit on white cards */
    [data-testid="stImage"], [data-testid="stPyplot"] {background: white; border: 1px solid #D6EAF8;
        border-radius: 16px; padding: .6rem; box-shadow: 0 4px 14px rgba(8,48,107,.06); margin: .3rem 0 .6rem 0;}
    [data-testid="stImage"] img, [data-testid="stPyplot"] img {border-radius: 10px;}
    [data-testid="stDataFrame"] {border: 1px solid #D6EAF8; border-radius: 12px; overflow: hidden;}
    [data-testid="stExpander"] {background: white; border: 1px solid #D6EAF8 !important; border-radius: 14px;}
    [data-testid="stExpander"] summary p {font-weight: 600; color: var(--navy) !important;}

    /* Buttons */
    .stDownloadButton button, .stButton button {background: linear-gradient(90deg, #08306B, #1D70A2);
        color: white !important; border: none; border-radius: 10px; font-weight: 600; padding: .5rem 1.1rem;}
    .stDownloadButton button p, .stButton button p {color: white !important;}
    .stDownloadButton button:hover, .stButton button:hover {filter: brightness(1.12);}

    /* Hide Streamlit chrome */
    #MainMenu, footer {visibility: hidden;}
    </style>
    """,
    unsafe_allow_html=True,
)


# --------------------------------------------------------------------------
# Small helpers
# --------------------------------------------------------------------------
def show_figure(figure):
    """Display a Matplotlib figure and free its memory."""
    st.pyplot(figure)
    plt.close(figure)


KPI_ICONS = {
    "Households analysed": "🏠", "Total recorded": "💧", "Average household": "📊",
    "Highest-consuming household": "🏆", "Peak month": "📈",
    "Households checked": "🔎", "Potential anomalies": "🚩", "Peer fence (average)": "📏",
    "Rule hits": "🎯", "Training months": "🗓️", "Test months": "🧪",
    "Households in training": "🏘️", "Best model (lowest MAE)": "🥇",
}


def kpi_card(title, value, subtitle="", tooltip=""):
    """Render one KPI card with an icon (hover for an explanation)."""
    icon = KPI_ICONS.get(title, "💧")
    st.markdown(
        f'<div class="kpi" title="{html.escape(tooltip)}"><div class="kpi-icon">{icon}</div>'
        f'<div class="kpi-body"><div class="kpi-title">{html.escape(title)}</div>'
        f'<div class="kpi-value">{html.escape(str(value))}</div>'
        f'<div class="kpi-sub">{html.escape(subtitle)}</div></div></div>',
        unsafe_allow_html=True,
    )


def section_header(title, subtitle=""):
    """Page title with a short description underneath."""
    st.markdown(f'<div class="section-title"><h2>{html.escape(title)}</h2>'
                f'<p>{html.escape(subtitle)}</p></div>', unsafe_allow_html=True)


def note(text, kind="note"):
    st.markdown(f'<div class="{kind}">{text}</div>', unsafe_allow_html=True)


def fmt(number, unit="", decimals=0):
    """Format a number with thousands separators and an optional unit."""
    if number is None or (isinstance(number, float) and np.isnan(number)):
        return "n/a"
    return f"{number:,.{decimals}f}" + (f" {unit}" if unit else "")


def month_text(value):
    return dp.month_label(value) if pd.notna(value) else ""


# --------------------------------------------------------------------------
# Data loading (cached so the 600-column CSV is read only once)
# --------------------------------------------------------------------------
@st.cache_data(show_spinner="Reading the survey CSV...")
def load_raw_from_disk(path_text):
    return dp.load_raw_data(path_text)


@st.cache_data(show_spinner="Reading the uploaded CSV...")
def load_raw_from_upload(file_bytes):
    return dp.load_raw_data_from_bytes(file_bytes)


@st.cache_data(show_spinner="Cleaning and preparing the data...")
def prepare_data(raw_df):
    return dp.build_working_dataset(raw_df)


@st.cache_data(show_spinner="Looking for unusual consumption...")
def cached_anomalies(wide, attributes, iqr_multiplier, z_threshold, spike_ratio, min_months):
    return analysis.detect_anomalies(
        wide, attributes, iqr_multiplier=iqr_multiplier, z_threshold=z_threshold,
        spike_ratio=spike_ratio, min_months=min_months)


@st.cache_resource(show_spinner="Training forecasting models (the first run can take a minute)...")
def cached_forecast(_wide, data_signature, lookback, test_months, use_tensorflow, epochs):
    # `_wide` is skipped by Streamlit's hashing; `data_signature` identifies the data instead.
    return fc.run_forecasting_pipeline(
        _wide, lookback=lookback, test_months=test_months,
        use_tensorflow=use_tensorflow, epochs=epochs)


def get_raw_dataframe():
    """Load the CSV from the data folder, or let the user upload it."""
    try:
        return load_raw_from_disk(str(DATA_PATH))
    except FileNotFoundError:
        st.warning(f"The dataset was not found at `{DATA_PATH}`. "
                   "Upload the CSV below (or copy it into the `data` folder).")
        uploaded = st.file_uploader("Upload Pune_HHLD_Survey_Data_v2-0-0.csv", type="csv")
        if uploaded is None:
            st.stop()
        return load_raw_from_upload(uploaded.getvalue())
    except ValueError as error:
        st.error(f"The dataset could not be read: {error}")
        st.stop()


# --------------------------------------------------------------------------
# Load + sidebar controls
# --------------------------------------------------------------------------
raw_df = get_raw_dataframe()
try:
    data = prepare_data(raw_df)
except ValueError as error:
    st.error(f"The dataset could not be processed: {error}")
    st.stop()

st.sidebar.markdown("## 💧 Smart Water Monitor")
page = st.sidebar.radio(
    "Navigate",
    ["Overview", "Consumption Analytics", "Anomaly Detection", "Demand Forecasting", "Data Explorer"],
    help="Choose a section of the dashboard.",
)

st.sidebar.markdown("---")
st.sidebar.markdown("**Data filters**")
unit_label = st.sidebar.text_input(
    "Unit label", value=dp.DEFAULT_UNIT_LABEL,
    help="The CSV has no data dictionary for the monthly columns, so their unit is not "
         "documented. Change this label if you confirm the unit (for example kL or INR).")
min_households_per_month = st.sidebar.number_input(
    "Min. households per month", min_value=1, max_value=int(data.wide.notna().sum().max()),
    value=300, step=50,
    help="Months with fewer households are hidden: averages over a handful of households "
         "are not reliable (Jan 2018 has only 14).")
usable_months = dp.well_covered_months(data.wide, min_households_per_month)
if len(usable_months) < 2:
    st.sidebar.error("Fewer than 2 months meet this limit. Lower the minimum.")
    st.stop()
selected_start, selected_end = st.sidebar.select_slider(
    "Months to include", options=usable_months, value=(usable_months[0], usable_months[-1]),
    format_func=dp.month_label, help="Filters every chart and table (except forecasting).")
min_months_history = st.sidebar.slider(
    "Min. months of history per household", 1, 12, 6,
    help="Households with fewer recorded months are left out of household-level analysis.")

period_wide = dp.select_period(data.wide, selected_start, selected_end)
period_wide = dp.filter_households(period_wide, min_months_history)
if period_wide.empty:
    st.warning("No households match the current filters. Relax them in the sidebar.")
    st.stop()

monthly_stats = analysis.monthly_summary(period_wide)
household_stats = analysis.household_summary(period_wide, data.attributes)
label_of = data.attributes["label"]
id_of_label = {label: household_id for household_id, label in label_of.items()}

st.sidebar.markdown("---")
st.sidebar.caption("Data: Pune Household Food-Water-Energy Consumption Survey. "
                   "Survey records - not real-time smart-meter data. No simulated data is used.")

st.markdown(
    '<div class="hero"><h1>💧 Smart Water Consumption Monitoring &amp; Demand Forecasting</h1>'
    "<p>Household water records from the Pune survey - analytics, anomaly detection and monthly forecasting</p>"
    '<span class="badge">📋 Survey data (not real-time)</span>'
    '<span class="badge">🗓️ Jan 2018 - Feb 2020</span>'
    '<span class="badge">🏠 705 households with monthly values</span></div>',
    unsafe_allow_html=True)


# ==========================================================================
# A. OVERVIEW
# ==========================================================================
def page_overview():
    note("<b>About this data.</b> These are <b>survey records</b>: each household was visited once and "
         "reported up to 12 recent months. They are <b>not real-time smart-meter readings</b>. "
         f"The unit of the monthly values is not documented in the CSV, so they are shown as "
         f"“{html.escape(unit_label)}”. Nothing on this dashboard is simulated.")
    st.write("")

    all_values = period_wide.to_numpy(dtype=float)
    observed = all_values[~np.isnan(all_values)]
    top_household = household_stats["mean"].idxmax()
    peak_month = monthly_stats["mean"].idxmax()

    columns = st.columns(5)
    with columns[0]:
        kpi_card("Households analysed", fmt(len(period_wide)),
                 f"of {fmt(data.quality['households_with_monthly_data'])} with monthly data",
                 "Households that meet the sidebar filters.")
    with columns[1]:
        kpi_card("Total recorded", fmt(observed.sum(), unit_label),
                 f"{fmt(observed.size)} household-months",
                 "Sum of all recorded household-month values in the selected period. "
                 "It is not a city total: only surveyed households are included.")
    with columns[2]:
        kpi_card("Average household", fmt(np.nanmean(period_wide.mean(axis=1)), unit_label, 1),
                 "per month (mean of household averages)",
                 "Each household counts once, whatever its number of recorded months.")
    with columns[3]:
        kpi_card("Highest-consuming household", label_of[top_household],
                 f"average {fmt(household_stats.at[top_household, 'mean'], unit_label)} per month",
                 "Household with the highest average monthly value. Not necessarily wastage.")
    with columns[4]:
        kpi_card("Peak month", month_text(peak_month),
                 f"average {fmt(monthly_stats.at[peak_month, 'mean'], unit_label, 1)}",
                 "Month with the highest average value across households.")

    section_header("📈 Monthly consumption summary", "Average, median and spread across households")
    show_figure(viz.plot_monthly_trend(monthly_stats, unit_label))
    table = monthly_stats.copy()
    table.index = [month_text(m) for m in table.index]
    table = table[["households", "mean", "median", "q1", "q3", "max", "total"]].round(1)
    table.columns = ["Households", "Average", "Median", "25th pct", "75th pct", "Max", "Total"]
    st.dataframe(table)
    st.caption("The mean is higher than the median in every month because a few households use far "
               "more than the rest (right-skewed data).")

    with st.expander("Data coverage and quality (what the CSV actually contains)"):
        quality = data.quality
        left, right = st.columns(2)
        with left:
            st.markdown(
                f"- Survey rows × columns: **{quality['survey_rows']:,} × {quality['survey_columns']}**\n"
                f"- Monthly columns: **{quality['monthly_columns']}** "
                f"({month_text(quality['first_month'])} to {month_text(quality['last_month'])})\n"
                f"- Households with any monthly value: **{quality['households_with_monthly_data']:,}**\n"
                f"- Households with a full 12 months: **{quality['households_with_12_months']:,}**\n"
                f"- Records are one unbroken block of months for **{quality['share_contiguous']*100:.1f}%** "
                f"of households")
        with right:
            st.markdown(
                f"- Duplicate household keys: **{quality['duplicate_household_keys']}**\n"
                f"- Negative values removed: **{quality['negative_values_removed']}**\n"
                f"- Zero values kept: **{quality['zero_values']}** (may be real, e.g. empty home)\n"
                f"- Largest single value: **{quality['max_observation']:,.0f}** "
                f"(median {quality['median_observation']:,.0f})\n"
                f"- Households with a monthly series identical to another household: "
                f"**{quality['households_with_identical_series']}** (shared bills or duplicate entries; kept)")
        show_figure(viz.plot_coverage(quality["households_per_month"]))


# ==========================================================================
# B. CONSUMPTION ANALYTICS
# ==========================================================================
def page_analytics():
    section_header("📊 Consumption analytics", "Trends, comparisons, distribution and heatmaps")
    st.caption(f"Showing {month_text(selected_start)} to {month_text(selected_end)} · "
               f"{len(period_wide):,} households. Change filters in the sidebar.")

    tab_trend, tab_households, tab_spread, tab_heatmap, tab_zone, tab_single = st.tabs(
        ["Monthly trend", "Household comparison", "Distribution & outliers", "Heatmap",
         "By zone", "Single household"])

    with tab_trend:
        balanced = st.checkbox(
            "Use only households recorded in every selected month (fairer trend)", value=False,
            help="The set of households changes from month to month. A balanced panel keeps the "
                 "same households in every month, so changes reflect usage, not sample changes.")
        trend_wide = period_wide
        if balanced:
            trend_wide = analysis.balanced_panel(period_wide, selected_start, selected_end)
            st.caption(f"Balanced panel: {len(trend_wide):,} households.")
        if trend_wide.empty:
            st.info("No household has a value in every selected month. Narrow the month range.")
        else:
            trend_stats = analysis.monthly_summary(trend_wide)
            show_figure(viz.plot_monthly_trend(trend_stats, unit_label))
            statistic = st.radio("Bar chart statistic", ["mean", "median", "total"], horizontal=True,
                                 help="'total' depends on how many households were recorded each month.")
            show_figure(viz.plot_monthly_bar(trend_stats, statistic, unit_label))
            if statistic == "total":
                st.caption("Totals rise and fall with the number of households recorded, so prefer "
                           "the mean or median when comparing months.")

    with tab_households:
        count = st.slider("Households to show", 5, 25, 10)
        top_table, bottom_table = analysis.top_and_bottom(household_stats, count)
        show_figure(viz.plot_household_bar(top_table, bottom_table, unit_label))
        columns_to_show = ["label", "ward", "zone", "household_size", "months_recorded", "mean",
                           "median", "max"]
        columns_to_show = [c for c in columns_to_show if c in household_stats.columns]
        left, right = st.columns(2)
        with left:
            st.markdown("**Highest**")
            st.dataframe(top_table[columns_to_show].round(1))
        with right:
            st.markdown("**Lowest**")
            st.dataframe(bottom_table[columns_to_show].round(1))
        st.caption("Household size is the number of people reported in the survey; a large family "
                   "naturally uses more water than a single person.")

    with tab_spread:
        left, right = st.columns(2)
        with left:
            log_scale = st.checkbox("Log scale", value=True,
                                    help="Consumption is very right-skewed; a log scale shows the whole shape.")
            show_figure(viz.plot_distribution(household_stats["mean"], unit_label, log_scale,
                                              "Distribution of household average values"))
        with right:
            st.markdown("**Summary of household averages**")
            st.dataframe(household_stats["mean"].describe().round(1).rename("value").to_frame())
        show_figure(viz.plot_boxplot_by_month(period_wide, unit_label))
        st.caption("Dots above the whiskers are potential outliers by the IQR rule. See the Anomaly "
                   "Detection page for a household-level view.")

    with tab_heatmap:
        count = st.slider("Households in heatmap", 15, 80, 40)
        show_figure(viz.plot_heatmap(period_wide, data.attributes, count, unit_label))
        st.caption("Darker = higher monthly value. Blank cells are months with no record.")

    with tab_zone:
        attribute_options = [c for c in ("zone", "ward", "household_size", "metered")
                             if c in household_stats.columns]
        attribute = st.selectbox("Group households by", attribute_options,
                                 help="Zone and ward are survey areas; 'metered' is 1 if the household has a water meter.")
        grouped = analysis.group_mean_by_attribute(household_stats, attribute)
        if grouped.empty:
            st.info("No data for this grouping.")
        else:
            figure, axis = plt.subplots(figsize=(8, 3.8))
            axis.bar(grouped.index.astype(int).astype(str), grouped["mean"], color=viz.WATER_BLUES[1])
            axis.set_xlabel(attribute)
            axis.set_ylabel(f"Average monthly value ({unit_label})")
            axis.set_title(f"Average household consumption by {attribute}")
            figure.tight_layout()
            show_figure(figure)
            st.dataframe(grouped.round(1).rename(columns={"count": "households"}))

    with tab_single:
        options = sorted(household_stats["label"].dropna())
        chosen_label = st.selectbox("Select a household", options)
        chosen_id = id_of_label[chosen_label]
        series = period_wide.loc[chosen_id]
        st.caption(f"Recorded {int(series.notna().sum())} months · average "
                   f"{fmt(series.mean(), unit_label, 1)} · peak {fmt(series.max(), unit_label)} "
                   f"in {month_text(series.idxmax())}")
        show_figure(viz.plot_household_series(series, monthly_stats, chosen_label, unit_label))
        attributes_row = data.attributes.loc[chosen_id].drop("label").dropna()
        st.dataframe(attributes_row.rename("value").to_frame())


# ==========================================================================
# C. ANOMALY DETECTION
# ==========================================================================
def page_anomalies():
    section_header("🚩 Potential anomalies", "Statistically unusual households - leads to check, not proof of wastage")
    note("<b>Read this first.</b> A household is flagged when its numbers are statistically unusual. "
         "That does <b>not</b> prove a leak or water wastage: a bigger family, guests, a changed billing "
         "cycle or a data-entry error can look the same. Treat flags as <b>leads to check</b>.")
    st.write("")

    with st.expander("Detection settings and rules", expanded=False):
        left, right, third = st.columns(3)
        with left:
            iqr_multiplier = st.slider("IQR multiplier", 1.0, 3.0, 1.5, 0.1,
                                       help="Upper fence = Q3 + multiplier × IQR. Higher = fewer flags.")
        with right:
            z_threshold = st.slider("Robust z-score threshold", 2.5, 6.0, 3.5, 0.1,
                                    help="How far a month is above the household's own typical value.")
        with third:
            spike_ratio = st.slider("Month-to-month jump (×)", 2.0, 6.0, 3.0, 0.5,
                                    help="Flag a month that is at least this many times the previous month.")
        st.markdown(
            "- **HIGH_AVERAGE** – the household's average is above the IQR upper fence of all household averages.\n"
            "- **PEER_OUTLIER** – in some month the value is above that month's IQR upper fence.\n"
            "- **OWN_SPIKE** – a month is a robust z-score outlier against the household's own history, "
            "or jumped by the multiple above versus the previous month (with a minimum absolute increase).\n"
            "- **CONSISTENTLY_HIGH** – above the 90th percentile of all households in at least 60% of its months.")

    flagged, details = cached_anomalies(period_wide, data.attributes, iqr_multiplier, z_threshold,
                                        spike_ratio, max(3, min_months_history))
    if flagged.empty:
        st.success("No households were flagged with the current settings.")
        return

    minimum_rules = st.slider("Show households with at least this many rules triggered", 1, 4, 2,
                              help="Households triggering several independent rules are the strongest leads.")
    shown = flagged[flagged["rules_triggered"] >= minimum_rules]

    columns = st.columns(4)
    with columns[0]:
        kpi_card("Households checked", fmt(details["households_checked"]), "enough months of history")
    with columns[1]:
        kpi_card("Potential anomalies", fmt(len(flagged)), f"{len(shown)} shown with ≥{minimum_rules} rules")
    with columns[2]:
        kpi_card("Peer fence (average)", fmt(details["average_upper_fence"], unit_label),
                 "household averages above this are high",
                 "Q3 + IQR multiplier × IQR of household averages.")
    with columns[3]:
        counts = details["rule_counts"]
        kpi_card("Rule hits", f"{counts['HIGH_AVERAGE']} / {counts['PEER_OUTLIER']} / "
                 f"{counts['OWN_SPIKE']} / {counts['CONSISTENTLY_HIGH']}",
                 "high avg / peer / spike / consistent")

    table = shown.copy()
    table["peak_month"] = table["peak_month"].map(month_text)
    table = table.rename(columns={
        "label": "Household", "ward": "Ward", "zone": "Zone", "household_size": "People",
        "months_recorded": "Months", "average": "Average", "peak_value": "Peak value",
        "peak_month": "Peak month", "largest_month_jump": "Largest monthly jump",
        "rules_triggered": "Rules", "rule_names": "Rules triggered", "reasons": "Why it was flagged",
        "status": "Status"})
    ordered_columns = [c for c in ["Household", "Ward", "Zone", "People", "Months", "Average",
                                   "Peak value", "Peak month", "Largest monthly jump", "Rules",
                                   "Why it was flagged", "Status"] if c in table.columns]
    st.dataframe(table[ordered_columns].round(1))
    st.download_button("Download flagged households (CSV)",
                       table.drop(columns=["household_id"]).to_csv(index=False).encode("utf-8"),
                       file_name="potential_anomalies.csv", mime="text/csv")

    st.subheader("Inspect a flagged household")
    inspect_label = st.selectbox("Household", list(shown["label"]))
    inspect_id = id_of_label[inspect_label]
    peer_fence_row = details["above_peer_fence_matrix"].loc[inspect_id]
    flagged_months = [m for m, is_flagged in peer_fence_row.items() if is_flagged]
    show_figure(viz.plot_household_series(period_wide.loc[inspect_id], monthly_stats, inspect_label,
                                          unit_label, flagged_months))
    st.caption("Orange dots are months above that month's peer IQR fence.")


# ==========================================================================
# D. DEMAND FORECASTING
# ==========================================================================
def page_forecasting():
    section_header("🔮 Monthly demand forecasting", "Chronological train/test experiment with honest limitations")
    tensorflow_ok = fc.tensorflow_available()
    note("<b>What is (and is not) possible.</b> The data are <b>monthly</b> survey records covering about "
         "one year per household, so only short-term <b>monthly</b> forecasts are attempted. "
         "<b>Daily forecasts are not possible</b> and yearly seasonality cannot be learned from one year.")
    st.write("")

    with st.expander("Experiment settings", expanded=True):
        left, middle, right = st.columns(3)
        with left:
            lookback = st.slider("Months of history per prediction", 2, 6, 3,
                                 help="The model sees this many past months to predict the next one.")
        with middle:
            test_months = st.slider("Test months (most recent)", 2, 5, 4,
                                    help="The LAST months are held out for testing. Splitting is "
                                         "chronological, never random.")
        with right:
            use_tensorflow = st.checkbox("Train TensorFlow neural network", value=tensorflow_ok,
                                         disabled=not tensorflow_ok,
                                         help="Needs TensorFlow (pip install tensorflow).")
        epochs = st.slider("Max training epochs", 20, 300, 150, 10, disabled=not use_tensorflow,
                           help="Training stops earlier if validation loss stops improving.")
    if not tensorflow_ok:
        st.info("TensorFlow is not installed in this Python environment, so the NumPy baselines are "
                "shown. Run `pip install tensorflow` and restart to add the neural network.")

    signature = (data.wide.shape, float(np.nansum(data.wide.to_numpy(dtype=float))))
    try:
        result = cached_forecast(data.wide, signature, lookback, test_months, use_tensorflow, epochs)
    except ValueError as error:
        st.error(f"The forecasting experiment could not run: {error}")
        return
    if result.tensorflow_message:
        st.warning(result.tensorflow_message)

    st.subheader("1. Chronological train / test split")
    columns = st.columns(4)
    with columns[0]:
        kpi_card("Training months", f"{month_text(result.train_months[0])} – "
                 f"{month_text(result.train_months[-1])}", f"{fmt(result.n_train)} samples")
    with columns[1]:
        kpi_card("Test months", f"{month_text(result.test_months[0])} – "
                 f"{month_text(result.test_months[-1])}", f"{fmt(result.n_test)} samples",
                 "Months the models never saw during training.")
    with columns[2]:
        kpi_card("Households in training", fmt(result.n_households_train), "pooled into one model")
    with columns[3]:
        kpi_card("Best model (lowest MAE)", result.best_model_name.split(" (")[0],
                 f"MAE {fmt(result.metrics['MAE'].min(), unit_label, 1)}")

    st.subheader("2. Performance on the test months")
    metrics_view = result.metrics.round(2)
    st.dataframe(metrics_view)
    st.caption("MAE = average absolute error; Median AE = typical error; RMSE punishes large errors "
               "(a few extreme households inflate it); MAPE = percentage error. "
               "'MAE vs naive %' below 0 means better than simply repeating last month.")

    naive_mae = result.metrics.loc["Naive (last month)", "MAE"]
    best_mae = result.metrics["MAE"].min()
    improvement = (1 - best_mae / naive_mae) * 100
    if result.best_model_name in ("Naive (last month)", "Moving average") or improvement < 5:
        note(f"<b>Honest reading:</b> the best model ({html.escape(result.best_model_name)}) improves on "
             f"repeating last month by only {improvement:.1f}%. With about one year of monthly data, "
             "simple baselines are hard to beat, so these forecasts should be treated as a rough guide.")
    else:
        note(f"<b>Reading:</b> {html.escape(result.best_model_name)} lowers the average error by "
             f"{improvement:.1f}% compared with repeating last month. This is one test period of only "
             f"{len(result.test_months)} months, so the gain may not hold in other periods.", "info")

    st.subheader("3. Actual vs predicted")
    model_names = list(result.metrics.index)
    selected_models = st.multiselect("Models to plot", model_names,
                                     default=[result.best_model_name, "Naive (last month)"]
                                     if result.best_model_name != "Naive (last month)" else model_names[:2])
    if selected_models:
        show_figure(viz.plot_actual_vs_predicted(result.monthly_comparison, selected_models, unit_label))
    left, right = st.columns(2)
    with left:
        show_figure(viz.plot_metric_comparison(result.metrics, "MAE", unit_label))
    with right:
        scatter_model = st.selectbox("Household-level scatter for", model_names,
                                     index=model_names.index(result.best_model_name))
        show_figure(viz.plot_prediction_scatter(result.test_samples, scatter_model, unit_label))

    st.subheader("4. Short-term forecast beyond the data")
    available_models = ["Naive (last month)", "Moving average"] + list(result.models)
    forecast_model = st.selectbox("Model", available_models,
                                  index=available_models.index(result.best_model_name))
    horizon = st.slider("Months ahead", 1, 3, 3,
                        help="Predictions are fed back in for the next step, so uncertainty grows each month.")
    windows, last_months = fc.latest_complete_windows(data.wide, result.lookback)
    latest_month = last_months.mode().iloc[0]
    latest_ids = last_months.index[last_months == latest_month]
    predictions = fc.forecast_ahead(windows.loc[latest_ids].to_numpy(), forecast_model, result.models, horizon)
    forecast_months = [latest_month + pd.DateOffset(months=step) for step in range(1, horizon + 1)]
    forecast_mean = pd.Series(predictions.mean(axis=0), index=forecast_months)
    history_months = [m for m in data.wide.columns if m <= latest_month][-6:]
    history_mean = data.wide.loc[latest_ids, history_months].mean()
    show_figure(viz.plot_future_forecast(history_mean, forecast_mean, unit_label))
    st.caption(f"Based on the {len(latest_ids):,} households whose records end in {month_text(latest_month)}. "
               "Illustrative only: no confidence intervals are produced and the model cannot see "
               "seasonal effects, tariff changes or weather.")

    pick_label = st.selectbox("Forecast for one household", sorted(label_of[latest_ids]))
    pick_id = id_of_label[pick_label]
    pick_position = list(latest_ids).index(pick_id)
    table = pd.DataFrame({
        "Month": [month_text(m) for m in forecast_months],
        f"Forecast ({unit_label})": predictions[pick_position].round(1)})
    st.dataframe(table.set_index("Month"))

    with st.expander("Method and limitations"):
        st.markdown(
            "**Method.** One model is trained on short windows pooled from all households "
            f"(last {result.lookback} months → next month). Each window is divided by its own average, so "
            "only past information is used. The split is chronological: training uses earlier target "
            "months, testing uses the latest ones. Windows with missing months are skipped; nothing is imputed. "
            "The TensorFlow network uses the last training month as a chronological validation set for early stopping.\n\n"
            "**Limitations.**\n"
            "- Each household has at most 12 months, so seasonal patterns cannot be learned reliably.\n"
            "- The test period is only a few months and the sample of households changes from month to month.\n"
            "- Extreme values (a few households with very large readings) dominate RMSE; MAE and Median AE are more reliable here.\n"
            "- The unit of the values is undocumented, and survey records may contain reporting errors.\n"
            "- Monthly data cannot support daily forecasts.")


# ==========================================================================
# E. DATA EXPLORER
# ==========================================================================
def page_explorer():
    section_header("🗂️ Data explorer", "Browse the original survey data and download the processed table")
    tab_original, tab_processed, tab_quality = st.tabs(
        ["Original survey data", "Processed monthly data", "Column guide"])

    with tab_original:
        st.caption(f"Original file: {raw_df.shape[0]:,} rows × {raw_df.shape[1]} columns (unchanged). "
                   "Pick the columns to preview.")
        groups = {
            "Identification": [c for c in ["interview__key", "ward", "zone", "household", "income"]
                               if c in raw_df.columns],
            "Monthly water values": list(data.month_columns),
            "Water bill": [c for c in ["metered", "bill", "billing_end", "billing_period",
                                       "waterbill_amount_1", "waterbill_consumption_1"]
                           if c in raw_df.columns],
            "Water sources and supply": [c for c in ["municipal_supply", "piped_water", "tanker_use",
                                                     "well_use", "storage", "capacity", "piped_hours",
                                                     "scarcity", "water_winter", "water_summer",
                                                     "water_monsoon"] if c in raw_df.columns],
            "Household water use (litres, survey answers)": [
                c for c in raw_df.columns if c.startswith("water_amount_")],
        }
        chosen_groups = st.multiselect("Column groups", list(groups),
                                       default=["Identification", "Water bill"])
        selectable = [c for group in chosen_groups for c in groups[group]]
        extra = st.multiselect("Or add any other column", [c for c in raw_df.columns if c not in selectable])
        preview_columns = selectable + extra
        only_with_monthly = st.checkbox("Only rows with monthly water values", value=True)
        rows_to_show = st.slider("Rows to preview", 10, 500, 50, 10)
        preview = raw_df[preview_columns] if preview_columns else raw_df.iloc[:, :8]
        if only_with_monthly:
            monthly_columns = list(data.month_columns)
            preview = preview[raw_df[monthly_columns].notna().any(axis=1)]
        st.dataframe(preview.head(rows_to_show))
        st.caption(f"{len(preview):,} rows match; showing the first {min(rows_to_show, len(preview))}.")

    with tab_processed:
        st.caption("Cleaned household × month table (missing months stay empty - nothing is invented).")
        left, middle, right = st.columns(3)
        with left:
            zone_choices = sorted(data.attributes["zone"].dropna().astype(int).unique())
            zones = st.multiselect("Zone", zone_choices, default=zone_choices)
        with middle:
            household_choices = st.multiselect("Households (leave empty for all)",
                                               sorted(data.attributes["label"]))
        with right:
            min_months_explorer = st.slider("Min. months recorded", 1, 12, 1, key="explorer_min")

        table = data.attributes.join(analysis.household_summary(data.wide)[["months_recorded", "mean", "max"]])
        table = table.join(data.wide)
        zone_mask = table["zone"].isin(zones)
        if len(zones) == len(zone_choices):  # everything selected -> also keep rows with no zone
            zone_mask = zone_mask | table["zone"].isna()
        table = table[zone_mask]
        table = table[table["months_recorded"] >= min_months_explorer]
        if household_choices:
            table = table[table["label"].isin(household_choices)]

        sort_column = st.selectbox("Sort by", ["label", "mean", "max", "months_recorded"], index=1)
        ascending = st.checkbox("Ascending", value=False)
        table = table.sort_values(sort_column, ascending=ascending)
        shown_table = table.rename(columns={c: month_text(c) for c in table.columns
                                            if isinstance(c, pd.Timestamp)})
        st.dataframe(shown_table.round(1))
        st.caption(f"{len(table):,} households.")
        st.download_button("Download processed data (CSV)",
                           shown_table.round(2).to_csv().encode("utf-8"),
                           file_name="processed_household_monthly_water.csv", mime="text/csv")

    with tab_quality:
        st.markdown(
            "**Monthly columns** (`Jan_2018` … `Feb_2020`): a monthly water value per household. "
            "No unit is documented in the CSV. They do not match the billed consumption columns "
            "(`waterbill_consumption_1`, in the survey's bill unit over `billing_period` days), so the two "
            "should not be mixed.\n\n"
            "**`metered`**: 1 if the household has a water meter. **`municipal_supply`**: 1 if it receives municipal "
            "piped water. **`zone` / `ward`**: survey areas. **`household`**: people in the household.\n\n"
            "Only 705 of the 1,872 surveyed households have monthly values; the rest are used only in the "
            "original-data preview.")
        st.dataframe(data.quality["households_per_month"].rename(index=month_text).to_frame("Households with a value"))


# --------------------------------------------------------------------------
# Router
# --------------------------------------------------------------------------
PAGES = {
    "Overview": page_overview,
    "Consumption Analytics": page_analytics,
    "Anomaly Detection": page_anomalies,
    "Demand Forecasting": page_forecasting,
    "Data Explorer": page_explorer,
}
PAGES[page]()
