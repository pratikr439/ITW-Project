# Smart Water Consumption Monitoring and Demand Forecasting System

B.Tech IT Workshop mini-project. It analyses household water records from the
**Pune Household Food-Water-Energy Consumption Survey** and presents them in an
interactive Streamlit dashboard.

## Run it

```bash
cd water_project
python -m venv venv                 # optional but recommended
venv\Scripts\activate               # Windows   (Linux/macOS: source venv/bin/activate)
pip install -r requirements.txt
streamlit run app.py
```

Optional: `python run_analysis.py` runs the whole analysis in the terminal and
saves charts to an `outputs/` folder (handy to check that everything works).

If `pip install tensorflow` fails (it supports only some Python versions), delete that
line from `requirements.txt`. The dashboard still works and shows the NumPy baselines;
the neural network is added automatically once TensorFlow is installed.

## What the data really is (read before presenting)

* **Survey data, not smart-meter data.** Each household was visited once and reported
  recent months. Nothing here is real-time and **no simulated data is used**.
* 1,872 survey rows × 606 columns; only the 26 monthly columns (`Jan_2018` … `Feb_2020`)
  are used for the time analysis. Only **705 households** have any monthly value, and each has
  **at most 12 consecutive months** (a window ending near its survey date).
* Coverage is dense only from **Feb 2019 to Jan 2020** (about 300–650 households per month);
  Jan 2018 has just 14. The dashboard therefore hides sparse months (sidebar filter).
* **The unit of the monthly values is not documented** in the CSV, and they do not agree with the
  separate bill columns (`waterbill_consumption_1`). The dashboard calls them “units”; change the
  label in the sidebar (or `DEFAULT_UNIT_LABEL` in `modules/data_processing.py`) once you confirm
  the unit with the dataset documentation. State this in your viva.
* 48 households have a monthly series identical to another household’s (shared bills or duplicate
  entries). They are kept and reported, not deleted.
* The original CSV is never modified; cleaning happens on a separate working copy. Missing months stay
  missing (no imputation); zeros and extreme values are kept and only flagged.

## Project structure

```
water_project/
├── app.py                      Streamlit dashboard (5 sections)
├── run_analysis.py             Command-line run of the full pipeline
├── data/Pune_HHLD_Survey_Data_v2-0-0.csv
├── modules/
│   ├── data_processing.py      Load CSV, detect monthly columns, clean, quality report
│   ├── analysis.py             Aggregations, IQR / z-score / spike anomaly rules
│   ├── visualization.py        Matplotlib + Seaborn charts
│   └── forecasting.py          Windowing, chronological split, baselines, Keras model
├── requirements.txt
└── README.md
```

## Dashboard sections

| Section | Contents |
|---|---|
| Overview | KPI cards (households, total recorded, average, highest household, peak month), monthly summary, data-quality panel |
| Consumption Analytics | Monthly trend (optional balanced panel), bar charts, top/bottom households, distribution, boxplots, heatmap, grouping by zone, single-household view; month filter in sidebar |
| Anomaly Detection | Four statistical rules with adjustable thresholds, flagged households with reasons, per-household chart. Labelled **potential anomalies**, never confirmed leaks or wastage |
| Demand Forecasting | Chronological train/test split, baselines + TensorFlow network, MAE / Median AE / RMSE / MAPE, actual vs predicted, 1–3 month ahead forecast, limitations |
| Data Explorer | Original data preview, column groups, household/zone filters, sorting, CSV download of processed data |

## Methods in brief

**Anomaly rules** (a household is flagged if any rule fires; more rules = stronger lead):
`HIGH_AVERAGE` (average above the IQR fence of all household averages), `PEER_OUTLIER` (a month above
that month’s IQR fence), `OWN_SPIKE` (robust z-score using median/MAD against the household’s own history,
or a ≥3× month-to-month jump, with minimum absolute increase), `CONSISTENTLY_HIGH` (above the 90th
percentile in ≥60% of months).

**Forecasting.** A household has too few points for its own model, so one model is trained on pooled
windows “last *k* months → next month”. Windows are divided by their own average (past values only).
The split is **chronological by target month** (train Feb–Sep 2019, test Oct 2019–Jan 2020 by default);
no random splitting. Windows with missing months are skipped. Models: naive (last month), moving average,
linear regression (NumPy least squares) and a small Keras network (Dense 16 → 8 → 1, Huber loss, early
stopping on a chronological validation month).

**Honest results.** On this data the simple baselines are about as good as the learned models, which is
expected with ≈1 year of monthly records. Daily forecasting is not possible from monthly survey data.

## Syllabus mapping

| Project feature | Library / module | IT Workshop module | How the concept is applied |
|---|---|---|---|
| Reusable functions in 4 modules + `app.py` | Python functions, `import` | Module I – Basics of Python | Every task is a function in `modules/`; the app and `run_analysis.py` reuse them |
| Reading the 3 MB CSV, trying encodings | `pathlib`, `pandas.read_csv`, loops | Module I – file handling & CSV | `load_raw_data` loops over encodings until the file decodes |
| Missing/corrupt file handling | `try / except` | Module I – exception handling | `FileNotFoundError`, `UnicodeDecodeError`, `ValueError` are caught and shown as clear messages |
| Finding monthly columns by name | loops, conditionals, `re` | Module I – loops & conditionals | `detect_monthly_columns` checks each column name against a pattern |
| Cleaning (negatives → missing, duplicates, numeric conversion) | Pandas DataFrame/Series | Module II – cleaning, missing values | `build_working_dataset` works on a copy; nothing invented |
| Household × month table, filters by months/history | Pandas indexing & boolean filtering | Module II – indexing & filtering | `select_period`, `filter_households`, `balanced_panel` |
| Monthly and household aggregation | Pandas `mean/median/quantile`, `GroupBy` | Module II – GroupBy, statistics | `monthly_summary`, `household_summary`, `group_mean_by_attribute` |
| Highest / lowest households | Pandas `sort_values` | Module II – sorting | `top_and_bottom` |
| IQR fences, robust z-score, jump ratio | NumPy arrays (`percentile`, `nanmedian`) | Module II – NumPy numerics | `iqr_fences`, `modified_z_scores`, `detect_anomalies` |
| Window building, scaling, least squares | NumPy slicing, `lstsq` | Module II – NumPy arrays | `build_windows`, `make_features`, `LinearRatioModel` |
| Monthly trend line plot | Matplotlib | Module III – line plots | `plot_monthly_trend` (mean, median, middle-50% band) |
| Monthly and household bar charts | Matplotlib, Seaborn palettes | Module III – bar charts | `plot_monthly_bar`, `plot_household_bar` |
| Household × month heatmap | Seaborn `heatmap` | Module III – heatmaps | `plot_heatmap` |
| Outlier detection by month | Seaborn `boxplot` | Module III – boxplots | `plot_boxplot_by_month` |
| Consumption distribution | Seaborn `histplot` (KDE) | Module III – distribution plots | `plot_distribution` |
| Actual vs predicted | Matplotlib | Module III – comparison plots | `plot_actual_vs_predicted`, `plot_prediction_scatter` |
| Neural-network forecast | TensorFlow / Keras `Sequential`, `Dense`, `EarlyStopping` | Module IV – TensorFlow | `KerasRatioModel` trained on chronological data, compared with baselines |
| Forecast metrics | NumPy | Module II/IV – evaluation | `forecast_metrics` (MAE, Median AE, RMSE, MAPE) |
| Interactive dashboard | Streamlit (extra, permitted) | Additional tool | Sidebar navigation, filters, KPI cards, downloads |

## Suggested viva points

* Why survey data cannot be called real-time, and why only 12 months per household limits forecasting.
* Why a chronological split is used and what data leakage would be.
* Why “flagged” does not mean “leak” (family size, guests, billing cycle, data errors).
* Why the mean exceeds the median (right-skewed data) and why MAE/Median AE are preferred over RMSE here.
