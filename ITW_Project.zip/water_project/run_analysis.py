"""
run_analysis.py - run the whole analysis from the command line (no dashboard).

    python run_analysis.py

Prints the data-quality report, top households, anomaly counts and forecasting
metrics, and saves the main charts as PNG files in the `outputs` folder.
Useful to check that everything works before starting the dashboard.
"""

from pathlib import Path

import matplotlib.pyplot as plt

from modules import analysis, data_processing as dp, forecasting as fc, visualization as viz

PROJECT_DIR = Path(__file__).parent
DATA_PATH = PROJECT_DIR / "data" / dp.DATA_FILE_NAME
OUTPUT_DIR = PROJECT_DIR / "outputs"
MIN_HOUSEHOLDS_PER_MONTH = 300  # months with fewer households are too sparse


def save_figure(figure, file_name):
    """Save a figure into the outputs folder and release its memory."""
    OUTPUT_DIR.mkdir(exist_ok=True)
    figure.savefig(OUTPUT_DIR / file_name, dpi=120)
    plt.close(figure)
    print(f"  saved outputs/{file_name}")


def main():
    # ---- Load and clean -----------------------------------------------------
    try:
        raw_df = dp.load_raw_data(DATA_PATH)
    except (FileNotFoundError, ValueError) as error:
        print(f"Cannot continue: {error}")
        return
    data = dp.build_working_dataset(raw_df)  # raw_df itself is not modified

    print("\n=== DATA QUALITY ===")
    for key, value in data.quality.items():
        if key != "households_per_month":
            print(f"  {key}: {value}")

    # ---- Analysis on well-covered months ---------------------------------------
    months = dp.well_covered_months(data.wide, MIN_HOUSEHOLDS_PER_MONTH)
    period = dp.filter_households(data.wide[months], min_months=6)
    monthly = analysis.monthly_summary(period)
    households = analysis.household_summary(period, data.attributes)

    print("\n=== MONTHLY SUMMARY (mean per household) ===")
    print(monthly[["households", "mean", "median"]].round(1).to_string())

    top, bottom = analysis.top_and_bottom(households, 5)
    print("\n=== HIGHEST AVERAGE HOUSEHOLDS ===")
    print(top[["label", "months_recorded", "mean", "max"]].round(1).to_string())

    # ---- Anomalies ---------------------------------------------------------------
    flagged, details = analysis.detect_anomalies(period, data.attributes)
    print(f"\n=== POTENTIAL ANOMALIES: {len(flagged)} of {details['households_checked']} households ===")
    print("  rule hits:", details["rule_counts"])
    print("  (statistical flags only - not confirmed leaks or wastage)")

    # ---- Forecasting -----------------------------------------------------------------
    result = fc.run_forecasting_pipeline(data.wide, lookback=3, test_months=4)
    print("\n=== FORECASTING (chronological split) ===")
    print(f"  train months: {result.train_months[0]:%b %Y} to {result.train_months[-1]:%b %Y}"
          f" ({result.n_train} samples)")
    print(f"  test months : {result.test_months[0]:%b %Y} to {result.test_months[-1]:%b %Y}"
          f" ({result.n_test} samples)")
    print(result.metrics.round(2).to_string())
    if result.tensorflow_message:
        print("  note:", result.tensorflow_message)

    # ---- Charts ---------------------------------------------------------------------
    print("\n=== SAVING CHARTS ===")
    save_figure(viz.plot_monthly_trend(monthly), "monthly_trend.png")
    save_figure(viz.plot_monthly_bar(monthly), "monthly_bar.png")
    save_figure(viz.plot_household_bar(top, bottom), "household_comparison.png")
    save_figure(viz.plot_heatmap(period, data.attributes), "heatmap.png")
    save_figure(viz.plot_boxplot_by_month(period), "boxplot.png")
    save_figure(viz.plot_distribution(households["mean"], log_scale=True), "distribution.png")
    save_figure(viz.plot_actual_vs_predicted(result.monthly_comparison, list(result.metrics.index)),
                "actual_vs_predicted.png")


if __name__ == "__main__":
    main()
