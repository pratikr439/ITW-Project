"""
forecasting.py
--------------
Monthly demand forecasting from the household x month table.

IT Workshop topics demonstrated here:
  * Module II : NumPy (arrays, least squares, slicing) and Pandas
  * Module IV : TensorFlow / Keras (a small neural network)

How the forecasting problem is set up
  * Each household has at most 12 monthly values, which is too short to train a
    model per household. Instead ONE model is trained on many short windows
    pooled from all households: "last `lookback` months -> next month".
  * Training and testing are split CHRONOLOGICALLY by the month being
    predicted: the test months are always later than every training month.
    No random shuffling of time-series observations is used.
  * Windows are scaled by their own average (only past values are used), so no
    information from the test period leaks into training.
  * Missing months are never filled in: a window is used only when all of its
    months and the target month are recorded.

Honest limitations (also shown on the dashboard)
  * About one year of data cannot teach a model the yearly seasonal pattern.
  * The data are monthly survey records, so daily forecasts are NOT possible.
  * Simple baselines (last month, moving average) are often hard to beat.
"""

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

RATIO_CLIP = 10.0  # ratios are limited to [0, 10] to stop one extreme value dominating training


# --------------------------------------------------------------------------
# TensorFlow availability
# --------------------------------------------------------------------------
def tensorflow_available():
    """True if TensorFlow can be imported (it is a large optional dependency)."""
    try:
        import tensorflow  # noqa: F401
        return True
    except Exception:  # ImportError, or a broken installation
        return False


# --------------------------------------------------------------------------
# Building supervised windows
# --------------------------------------------------------------------------
@dataclass
class WindowDataset:
    """Pooled (window -> next value) samples from many households."""
    inputs: np.ndarray            # shape (n_samples, lookback), raw values
    targets: np.ndarray           # shape (n_samples,), raw next-month value
    household_ids: np.ndarray     # shape (n_samples,)
    target_months: np.ndarray     # shape (n_samples,), datetime64 of the month predicted


def build_windows(wide, lookback=3, min_samples_per_month=100):
    """Create samples [m-lookback ... m-1] -> m for every fully recorded window.

    Target months with fewer than `min_samples_per_month` samples are dropped,
    because the monthly columns are very sparse at the start and end of the range.
    """
    months = list(wide.columns)
    values = wide.to_numpy(dtype=float)

    input_blocks, target_blocks, id_blocks, month_blocks = [], [], [], []
    for target_index in range(lookback, len(months)):
        window = values[:, target_index - lookback:target_index]
        target = values[:, target_index]
        # Use only complete windows: nothing is imputed.
        complete = ~np.isnan(window).any(axis=1) & ~np.isnan(target)
        if complete.sum() < min_samples_per_month:
            continue
        input_blocks.append(window[complete])
        target_blocks.append(target[complete])
        id_blocks.append(np.asarray(wide.index)[complete])
        month_blocks.append(np.full(complete.sum(), np.datetime64(months[target_index], "M")))

    if not input_blocks:
        raise ValueError("Not enough complete windows to build a forecasting dataset.")
    return WindowDataset(
        inputs=np.vstack(input_blocks),
        targets=np.concatenate(target_blocks),
        household_ids=np.concatenate(id_blocks),
        target_months=np.concatenate(month_blocks),
    )


def chronological_split(dataset, test_months=4):
    """Split by target month: the last `test_months` months are the test set.

    Returns boolean masks (train_mask, test_mask) and the month lists. An
    assertion guarantees that every training month is earlier than every test month.
    """
    unique_months = np.unique(dataset.target_months)
    if len(unique_months) <= test_months + 1:
        raise ValueError("Too few months to split into train and test sets.")
    test_set = unique_months[-test_months:]
    train_set = unique_months[:-test_months]
    assert train_set.max() < test_set.min(), "Training data must be older than test data"

    test_mask = np.isin(dataset.target_months, test_set)
    train_mask = np.isin(dataset.target_months, train_set)
    return train_mask, test_mask, train_set, test_set


# --------------------------------------------------------------------------
# Feature scaling (uses only each window's own past values)
# --------------------------------------------------------------------------
def window_scale(inputs):
    """Average of each window; windows averaging 0 use 1 to avoid dividing by 0."""
    average = inputs.mean(axis=1)
    return np.where(average > 0, average, 1.0)


def make_features(inputs):
    """Features = window values / window average, plus log of the average level."""
    scale = window_scale(inputs)
    ratios = np.clip(inputs / scale[:, None], 0, RATIO_CLIP)
    level = np.log1p(scale)[:, None]
    return np.hstack([ratios, level])


def make_ratio_targets(inputs, targets):
    """Training target: next value divided by the window average (clipped)."""
    return np.clip(targets / window_scale(inputs), 0, RATIO_CLIP)


# --------------------------------------------------------------------------
# Baseline models (plain NumPy)
# --------------------------------------------------------------------------
def predict_naive(inputs):
    """Baseline 1: next month equals the last observed month."""
    return inputs[:, -1]


def predict_moving_average(inputs):
    """Baseline 2: next month equals the average of the window."""
    return inputs.mean(axis=1)


class LinearRatioModel:
    """Linear regression solved with NumPy least squares (Module II baseline)."""

    def __init__(self):
        self.coefficients = None

    def fit(self, features, ratio_targets):
        design = np.hstack([features, np.ones((len(features), 1))])  # add intercept
        self.coefficients, *_ = np.linalg.lstsq(design, ratio_targets, rcond=None)
        return self

    def predict_ratio(self, features):
        design = np.hstack([features, np.ones((len(features), 1))])
        return design @ self.coefficients


# --------------------------------------------------------------------------
# TensorFlow / Keras model (Module IV)
# --------------------------------------------------------------------------
class KerasRatioModel:
    """Small fully connected neural network built with tf.keras."""

    def __init__(self, seed=42, epochs=150, batch_size=64):
        self.seed = seed
        self.epochs = epochs
        self.batch_size = batch_size
        self.model = None
        self.history = None

    def fit(self, features, ratio_targets, validation_features, validation_targets):
        import tensorflow as tf  # imported here so the project works without it

        tf.keras.utils.set_random_seed(self.seed)  # reproducible results

        self.model = tf.keras.Sequential([
            tf.keras.layers.Input(shape=(features.shape[1],)),
            tf.keras.layers.Dense(16, activation="relu"),
            tf.keras.layers.Dense(8, activation="relu"),
            tf.keras.layers.Dense(1),  # predicted ratio next/average
        ])
        # Huber loss is less sensitive to the extreme values in this dataset than MSE.
        self.model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),
                           loss=tf.keras.losses.Huber(), metrics=["mae"])

        # The validation set is the LAST training month (chronological, not random).
        early_stopping = tf.keras.callbacks.EarlyStopping(
            monitor="val_loss", patience=15, restore_best_weights=True)
        self.history = self.model.fit(
            features, ratio_targets,
            validation_data=(validation_features, validation_targets),
            epochs=self.epochs, batch_size=self.batch_size,
            callbacks=[early_stopping], verbose=0, shuffle=True,
        )
        return self

    def predict_ratio(self, features):
        return self.model.predict(features, verbose=0).ravel()


# --------------------------------------------------------------------------
# Metrics
# --------------------------------------------------------------------------
def forecast_metrics(actual, predicted):
    """MAE, median absolute error, RMSE and MAPE (zeros excluded from MAPE)."""
    actual = np.asarray(actual, dtype=float)
    predicted = np.asarray(predicted, dtype=float)
    errors = predicted - actual
    non_zero = actual > 0
    return {
        "MAE": float(np.mean(np.abs(errors))),
        "Median AE": float(np.median(np.abs(errors))),
        "RMSE": float(np.sqrt(np.mean(errors ** 2))),
        "MAPE %": float(np.mean(np.abs(errors[non_zero]) / actual[non_zero]) * 100)
        if non_zero.any() else float("nan"),
    }


# --------------------------------------------------------------------------
# Full pipeline
# --------------------------------------------------------------------------
@dataclass
class ForecastResult:
    """Everything the dashboard needs to show about the forecasting experiment."""
    metrics: pd.DataFrame                 # one row per model
    test_samples: pd.DataFrame            # household, month, actual, predictions
    monthly_comparison: pd.DataFrame      # average actual vs predicted per test month
    train_months: list
    test_months: list
    lookback: int
    n_train: int
    n_test: int
    n_households_train: int
    models: dict = field(default_factory=dict)   # fitted models by name
    tensorflow_used: bool = False
    tensorflow_message: str = ""
    best_model_name: str = ""


def run_forecasting_pipeline(wide, lookback=3, test_months=4, use_tensorflow=True,
                             epochs=150, seed=42, min_samples_per_month=100):
    """Train and evaluate baselines (+ a Keras model if TensorFlow is available)."""
    dataset = build_windows(wide, lookback, min_samples_per_month)
    train_mask, test_mask, train_month_set, test_month_set = chronological_split(dataset, test_months)

    train_inputs, test_inputs = dataset.inputs[train_mask], dataset.inputs[test_mask]
    train_targets, test_targets = dataset.targets[train_mask], dataset.targets[test_mask]

    train_features = make_features(train_inputs)
    test_features = make_features(test_inputs)
    train_ratio_targets = make_ratio_targets(train_inputs, train_targets)

    predictions = {
        "Naive (last month)": predict_naive(test_inputs),
        "Moving average": predict_moving_average(test_inputs),
    }
    models = {}

    # Linear regression with NumPy.
    linear_model = LinearRatioModel().fit(train_features, train_ratio_targets)
    predictions["Linear regression (NumPy)"] = (
        np.clip(linear_model.predict_ratio(test_features), 0, None) * window_scale(test_inputs))
    models["Linear regression (NumPy)"] = linear_model

    # Keras neural network (optional).
    tensorflow_used, tensorflow_message = False, ""
    if use_tensorflow:
        if tensorflow_available():
            try:
                train_months_of_samples = dataset.target_months[train_mask]
                last_train_month = train_month_set.max()
                validation_mask = train_months_of_samples == last_train_month
                fit_mask = ~validation_mask  # chronological validation split
                keras_model = KerasRatioModel(seed=seed, epochs=epochs).fit(
                    train_features[fit_mask], train_ratio_targets[fit_mask],
                    train_features[validation_mask], train_ratio_targets[validation_mask],
                )
                predictions["Neural network (TensorFlow/Keras)"] = (
                    np.clip(keras_model.predict_ratio(test_features), 0, None)
                    * window_scale(test_inputs))
                models["Neural network (TensorFlow/Keras)"] = keras_model
                tensorflow_used = True
            except Exception as error:  # keep the app alive if training fails
                tensorflow_message = f"TensorFlow model could not be trained: {error}"
        else:
            tensorflow_message = ("TensorFlow is not installed, so only the NumPy "
                                  "baselines were run. Install it with: pip install tensorflow")

    metric_rows = []
    for name, predicted in predictions.items():
        row = {"Model": name}
        row.update(forecast_metrics(test_targets, predicted))
        metric_rows.append(row)
    metrics = pd.DataFrame(metric_rows).set_index("Model")
    naive_mae = metrics.loc["Naive (last month)", "MAE"]
    metrics["MAE vs naive %"] = (metrics["MAE"] / naive_mae - 1) * 100  # negative = better than naive

    test_samples = pd.DataFrame({
        "household_id": dataset.household_ids[test_mask],
        "month": pd.to_datetime(dataset.target_months[test_mask].astype("datetime64[M]")),
        "actual": test_targets,
    })
    for name, predicted in predictions.items():
        test_samples[name] = predicted

    monthly_comparison = test_samples.groupby("month").mean(numeric_only=True)
    monthly_comparison["households"] = test_samples.groupby("month").size()

    result = ForecastResult(
        metrics=metrics, test_samples=test_samples, monthly_comparison=monthly_comparison,
        train_months=[pd.Timestamp(m) for m in train_month_set.astype("datetime64[M]")],
        test_months=[pd.Timestamp(m) for m in test_month_set.astype("datetime64[M]")],
        lookback=lookback, n_train=int(train_mask.sum()), n_test=int(test_mask.sum()),
        n_households_train=int(len(np.unique(dataset.household_ids[train_mask]))),
        models=models, tensorflow_used=tensorflow_used, tensorflow_message=tensorflow_message,
        best_model_name=str(metrics["MAE"].idxmin()),
    )
    return result


# --------------------------------------------------------------------------
# Forecasting the future (recursive, a few months ahead)
# --------------------------------------------------------------------------
def forecast_ahead(recent_values, model_name, models, horizon=3):
    """Predict `horizon` months after the given recent values.

    recent_values : array of shape (n_households, lookback) with the latest
                    recorded months (oldest first).
    The prediction is fed back as input for the next step (recursive
    forecasting), so uncertainty grows with every extra month.
    """
    window = np.asarray(recent_values, dtype=float).copy()
    steps = []
    for _ in range(horizon):
        if model_name == "Naive (last month)":
            next_value = predict_naive(window)
        elif model_name == "Moving average":
            next_value = predict_moving_average(window)
        else:
            ratio = models[model_name].predict_ratio(make_features(window))
            next_value = np.clip(ratio, 0, None) * window_scale(window)
        steps.append(next_value)
        window = np.hstack([window[:, 1:], next_value[:, None]])  # slide the window
    return np.column_stack(steps)


def latest_complete_windows(wide, lookback):
    """For every household, its most recent `lookback` consecutive recorded months.

    Returns (windows DataFrame, last_month Series). Households whose last
    `lookback` months contain a gap are skipped (nothing is imputed).
    """
    rows, ids, last_months = [], [], []
    months = list(wide.columns)
    for household_id, series in wide.iterrows():  # loop over households
        recorded_positions = np.flatnonzero(series.notna().to_numpy())
        if recorded_positions.size < lookback:
            continue
        last_position = recorded_positions[-1]
        window_positions = np.arange(last_position - lookback + 1, last_position + 1)
        if window_positions[0] < 0 or series.iloc[window_positions].isna().any():
            continue
        rows.append(series.iloc[window_positions].to_numpy(dtype=float))
        ids.append(household_id)
        last_months.append(months[last_position])
    windows = pd.DataFrame(rows, index=ids)
    return windows, pd.Series(last_months, index=ids, name="last_month")
