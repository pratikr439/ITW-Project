"""
data_processing.py
------------------
Loading, validation and preprocessing of the Pune Household Survey CSV.

IT Workshop topics demonstrated here:
  * Module I  : functions, loops, conditionals, file handling, exception handling
  * Module II : Pandas DataFrames/Series, NumPy, indexing, missing-value handling

Important facts about the data (found by inspecting the CSV):
  * 1,872 survey rows x 606 columns. Only a small part is about water use.
  * 26 monthly columns (Jan_2018 ... Feb_2020) hold a monthly water value.
  * Only 705 households have any monthly value, and each has at most 12
    consecutive months (a rolling window that ends near the survey date).
  * This is SURVEY data (one visit per household), NOT smart-meter data.
  * The CSV has no data dictionary, so the unit of the monthly values is not
    documented. The code therefore calls them "units" and the unit label can be
    changed in one place (DEFAULT_UNIT_LABEL).
"""

from dataclasses import dataclass, field
from pathlib import Path
import re

import numpy as np
import pandas as pd

# --------------------------------------------------------------------------
# Constants
# --------------------------------------------------------------------------
DATA_FILE_NAME = "Pune_HHLD_Survey_Data_v2-0-0.csv"
DEFAULT_UNIT_LABEL = "units"  # unit is undocumented in the CSV -> neutral label

# Month names exactly as they appear in the CSV column names -> month number.
MONTH_NAME_TO_NUMBER = {
    "jan": 1, "feb": 2, "mar": 3, "april": 4, "may": 5, "june": 6,
    "july": 7, "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12,
}
MONTH_COLUMN_PATTERN = re.compile(r"^([A-Za-z]+)_(\d{4})$")

# Household attribute columns we keep next to the monthly values, with
# friendlier names. Only columns that exist in the file are used.
ATTRIBUTE_COLUMN_RENAMES = {
    "ward": "ward",
    "zone": "zone",
    "household": "household_size",
    "income": "income_category",
    "metered": "metered",
    "municipal_supply": "municipal_supply",
    "waterbill_consumption_1": "bill_consumption_kl",
    "billing_period": "billing_period_days",
    "waterbill_amount_1": "bill_amount_inr",
}


# --------------------------------------------------------------------------
# Loading
# --------------------------------------------------------------------------
def load_raw_data(csv_path):
    """Read the original CSV file and return it untouched as a DataFrame.

    The survey file is not UTF-8 (it was exported as Windows-1252), so we try
    several encodings. Raises FileNotFoundError / ValueError with a clear
    message when the file cannot be read.
    """
    csv_path = Path(csv_path)
    if not csv_path.exists():
        raise FileNotFoundError(f"Dataset not found: {csv_path}")

    last_error = None
    for encoding in ("utf-8", "cp1252", "latin-1"):  # loop over fallbacks
        try:
            return pd.read_csv(csv_path, encoding=encoding, low_memory=False)
        except UnicodeDecodeError as error:
            last_error = error  # try the next encoding
        except pd.errors.EmptyDataError as error:
            raise ValueError(f"The file {csv_path} is empty.") from error
    raise ValueError(f"Could not decode {csv_path}: {last_error}")


def load_raw_data_from_bytes(file_bytes):
    """Same as load_raw_data but for an uploaded file held in memory."""
    import io
    last_error = None
    for encoding in ("utf-8", "cp1252", "latin-1"):
        try:
            return pd.read_csv(io.BytesIO(file_bytes), encoding=encoding, low_memory=False)
        except UnicodeDecodeError as error:
            last_error = error
        except pd.errors.EmptyDataError as error:
            raise ValueError("The uploaded file is empty.") from error
    raise ValueError(f"Could not decode the uploaded file: {last_error}")


# --------------------------------------------------------------------------
# Detecting the monthly columns
# --------------------------------------------------------------------------
def detect_monthly_columns(column_names):
    """Find columns named like 'Feb_2019' and map each to a month Timestamp.

    Columns are found by NAME (never by position) and returned sorted by date.
    """
    found = {}
    for name in column_names:
        match = MONTH_COLUMN_PATTERN.match(str(name))
        if match is None:
            continue
        month_number = MONTH_NAME_TO_NUMBER.get(match.group(1).lower())
        if month_number is None:
            continue  # looks like "something_2019" but is not a month
        found[name] = pd.Timestamp(year=int(match.group(2)), month=month_number, day=1)
    return dict(sorted(found.items(), key=lambda item: item[1]))


# --------------------------------------------------------------------------
# Result container
# --------------------------------------------------------------------------
@dataclass
class ProcessedData:
    """Everything the rest of the project needs, built from the raw CSV."""

    wide: pd.DataFrame          # rows = households, columns = months (values or NaN)
    attributes: pd.DataFrame    # one row per household in `wide`
    month_columns: dict         # original column name -> month Timestamp
    quality: dict = field(default_factory=dict)  # data-quality report

    @property
    def months(self):
        return list(self.wide.columns)


# --------------------------------------------------------------------------
# Preprocessing
# --------------------------------------------------------------------------
def build_working_dataset(raw_df):
    """Create the cleaned working dataset. `raw_df` is never modified.

    Cleaning rules (nothing is invented or silently filled in):
      * values are converted to numbers; unreadable text becomes NaN
      * negative values are impossible for consumption -> NaN (and counted)
      * missing months stay NaN (no imputation)
      * households with no monthly value at all are dropped from the working set
      * duplicate household keys are removed (none exist in this file)
    Zeros and extreme values are KEPT (they may be real); they are only
    reported in the quality report and handled by the anomaly module.
    """
    working = raw_df.copy()  # separate working copy -> original stays intact

    month_columns = detect_monthly_columns(working.columns)
    if not month_columns:
        raise ValueError("No monthly columns such as 'Feb_2019' were found in the file.")

    # Household id: the survey's own unique interview key.
    duplicate_rows = int(working["interview__key"].duplicated().sum())
    working = working.drop_duplicates(subset="interview__key", keep="first")

    # Short readable label based on the original row number, e.g. HH0007.
    working["household_label"] = [f"HH{index + 1:04d}" for index in working.index]

    monthly = working[list(month_columns)].apply(pd.to_numeric, errors="coerce")
    monthly.columns = list(month_columns.values())  # column names become Timestamps

    negative_values = int((monthly < 0).sum().sum())
    monthly = monthly.mask(monthly < 0)  # impossible values -> missing

    has_any_value = monthly.notna().any(axis=1)
    wide = monthly[has_any_value].copy()
    wide.index = working.loc[has_any_value, "interview__key"].values
    wide.index.name = "household_id"

    # Household attributes (only the columns that exist).
    attribute_frame = pd.DataFrame(index=wide.index)
    attribute_frame["label"] = working.loc[has_any_value, "household_label"].values
    for original_name, new_name in ATTRIBUTE_COLUMN_RENAMES.items():
        if original_name in working.columns:
            attribute_frame[new_name] = pd.to_numeric(
                working.loc[has_any_value, original_name], errors="coerce"
            ).values

    quality = build_quality_report(raw_df, wide, month_columns, duplicate_rows, negative_values)
    return ProcessedData(wide=wide, attributes=attribute_frame,
                         month_columns=month_columns, quality=quality)


# --------------------------------------------------------------------------
# Data-quality report
# --------------------------------------------------------------------------
def _is_contiguous(row_values):
    """True when a household's recorded months form one unbroken block."""
    positions = np.flatnonzero(~np.isnan(row_values))
    if positions.size == 0:
        return True
    return positions[-1] - positions[0] + 1 == positions.size


def build_quality_report(raw_df, wide, month_columns, duplicate_rows, negative_values):
    """Collect simple facts about the data (used on the dashboard and in README)."""
    values = wide.to_numpy(dtype=float)
    months_per_household = np.sum(~np.isnan(values), axis=1)
    observed = values[~np.isnan(values)]
    contiguous_flags = [_is_contiguous(row) for row in values]

    return {
        "survey_rows": int(len(raw_df)),
        "survey_columns": int(raw_df.shape[1]),
        "monthly_columns": len(month_columns),
        "first_month": min(month_columns.values()),
        "last_month": max(month_columns.values()),
        "households_with_monthly_data": int(len(wide)),
        "households_without_monthly_data": int(len(raw_df) - len(wide) - duplicate_rows),
        "duplicate_household_keys": duplicate_rows,
        "negative_values_removed": negative_values,
        "households_with_identical_series": int(len(find_identical_series(wide))),
        "zero_values": int(np.sum(observed == 0)),
        "total_observations": int(observed.size),
        "max_observation": float(observed.max()) if observed.size else float("nan"),
        "median_observation": float(np.median(observed)) if observed.size else float("nan"),
        "max_months_per_household": int(months_per_household.max()) if len(wide) else 0,
        "households_with_12_months": int(np.sum(months_per_household >= 12)),
        "share_contiguous": float(np.mean(contiguous_flags)) if contiguous_flags else float("nan"),
        "households_per_month": wide.notna().sum().rename("households"),
    }


def find_identical_series(wide):
    """Households whose whole monthly series is identical to another household's.

    This can happen when neighbours share one bill or when a record was entered
    twice. We only REPORT it; no row is deleted because we cannot tell which.
    """
    signatures = wide.fillna(-1).astype(int).astype(str).agg("|".join, axis=1)
    counts = signatures.map(signatures.value_counts())
    return wide.index[counts > 1]


# --------------------------------------------------------------------------
# Selecting subsets for each feature
# --------------------------------------------------------------------------
def filter_households(wide, min_months):
    """Keep households with at least `min_months` recorded months."""
    enough_history = wide.notna().sum(axis=1) >= min_months
    return wide[enough_history]


def select_period(wide, start_month, end_month):
    """Keep only the months between start_month and end_month (inclusive)."""
    in_range = [m for m in wide.columns if start_month <= m <= end_month]
    period = wide[in_range]
    return period[period.notna().any(axis=1)]  # drop households empty in this period


def well_covered_months(wide, min_households):
    """Months where at least `min_households` households have a value.

    The monthly columns are sparse at the start and end of the range (only
    14 households in Jan 2018!). Averages over such months are not reliable.
    """
    counts = wide.notna().sum()
    return [month for month, count in counts.items() if count >= min_households]


def to_long_format(wide):
    """Convert wide (household x month) data to a tidy table, dropping NaN."""
    long_table = wide.stack().rename("value").reset_index()
    long_table.columns = ["household_id", "month", "value"]
    return long_table


def month_label(timestamp):
    """Readable label such as 'Feb 2019'."""
    return pd.Timestamp(timestamp).strftime("%b %Y")
