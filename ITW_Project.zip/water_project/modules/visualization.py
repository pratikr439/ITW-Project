"""
visualization.py
----------------
All charts of the project, built with Matplotlib and Seaborn.
Every function returns a Matplotlib Figure so the Streamlit app (or a plain
script) can display or save it.

IT Workshop topics demonstrated here:
  * Module III : line plots, bar charts, heatmaps, boxplots, distribution
                 plots and actual-vs-predicted plots
"""

import matplotlib

matplotlib.use("Agg")  # draw without a window (works inside Streamlit and scripts)
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

# Blue / white water theme used by the charts and the dashboard.
WATER_BLUES = ["#08306B", "#1D70A2", "#4A9FD1", "#8EC5E8", "#D6EAF8"]
ACCENT = "#F28E2B"      # used sparingly for flagged values and predictions
GRID_COLOR = "#E3EDF5"


def apply_theme():
    """Set one consistent style for every chart."""
    sns.set_theme(style="whitegrid", rc={
        "axes.edgecolor": "#B8CCDC", "grid.color": GRID_COLOR,
        "axes.labelcolor": "#16324F", "xtick.color": "#16324F", "ytick.color": "#16324F",
        "axes.titleweight": "bold", "axes.titlecolor": "#08306B",
        "axes.spines.top": False, "axes.spines.right": False,
        "figure.facecolor": "white", "axes.facecolor": "white",
    })


apply_theme()


def _month_labels(months):
    return [pd.Timestamp(m).strftime("%b %y") for m in months]


def _empty_figure(message):
    figure, axis = plt.subplots(figsize=(8, 3))
    axis.text(0.5, 0.5, message, ha="center", va="center", color="#16324F")
    axis.axis("off")
    return figure


# --------------------------------------------------------------------------
# Line plot - monthly trend
# --------------------------------------------------------------------------
def plot_monthly_trend(summary, unit_label="units", show_band=True, highlight=None):
    """Line plot of the average (and median) per month with the middle-50% band.

    `highlight` is an optional Series (month -> value) drawn for one household.
    The number of households in each month is shown under the axis because the
    sample size changes a lot from month to month.
    """
    if summary.empty:
        return _empty_figure("No months selected")
    figure, axis = plt.subplots(figsize=(10, 4.6))
    positions = np.arange(len(summary))

    if show_band:
        axis.fill_between(positions, summary["q1"], summary["q3"],
                          color=WATER_BLUES[3], alpha=0.35, label="Middle 50% of households")
    axis.plot(positions, summary["mean"], marker="o", color=WATER_BLUES[0], linewidth=2.4,
              label="Average")
    axis.plot(positions, summary["median"], marker="s", color=WATER_BLUES[2], linewidth=2,
              linestyle="--", label="Median")
    if highlight is not None:
        highlight = highlight.reindex(summary.index)
        axis.plot(positions, highlight.values, marker="D", color=ACCENT, linewidth=2,
                  label="Selected household")

    labels = [f"{label}\n(n={count})" for label, count in
              zip(_month_labels(summary.index), summary["households"])]
    axis.set_xticks(positions)
    axis.set_xticklabels(labels, fontsize=8)
    axis.set_ylabel(f"Monthly value ({unit_label})")
    axis.set_title("Monthly water consumption per household")
    axis.legend(frameon=False, loc="upper left", ncol=2)
    figure.tight_layout()
    return figure


# --------------------------------------------------------------------------
# Bar charts
# --------------------------------------------------------------------------
def plot_monthly_bar(summary, column="mean", unit_label="units"):
    """Bar chart of one monthly statistic (mean, median or total)."""
    if summary.empty:
        return _empty_figure("No months selected")
    figure, axis = plt.subplots(figsize=(10, 4.2))
    colors = sns.color_palette("Blues_d", n_colors=len(summary))
    axis.bar(_month_labels(summary.index), summary[column], color=colors)
    axis.set_ylabel(f"{column.capitalize()} ({unit_label})")
    axis.set_title(f"Monthly {column} consumption")
    axis.tick_params(axis="x", rotation=45)
    figure.tight_layout()
    return figure


def plot_household_bar(top_table, bottom_table, unit_label="units"):
    """Two horizontal bar charts: highest and lowest consuming households."""
    figure, (axis_top, axis_bottom) = plt.subplots(1, 2, figsize=(11, 4.6))
    for axis, table, color, title in (
        (axis_top, top_table, WATER_BLUES[0], "Highest average consumption"),
        (axis_bottom, bottom_table, WATER_BLUES[2], "Lowest average consumption"),
    ):
        labels = table["label"] if "label" in table.columns else table.index.astype(str)
        axis.barh(labels, table["mean"], color=color)
        axis.invert_yaxis()
        axis.set_xlabel(f"Average monthly value ({unit_label})")
        axis.set_title(title)
    figure.tight_layout()
    return figure


# --------------------------------------------------------------------------
# Heatmap
# --------------------------------------------------------------------------
def plot_heatmap(wide, attributes=None, max_households=40, unit_label="units"):
    """Heatmap of the households with the most complete history (x = month).

    The colour scale stops at the 95th percentile so a few extreme households
    do not wash out every other cell. Blank cells are months with no record.
    """
    if wide.empty:
        return _empty_figure("No data for the heatmap")
    completeness = wide.notna().sum(axis=1)
    ranked = wide.assign(_n=completeness, _mean=wide.mean(axis=1))
    chosen = ranked.sort_values(["_n", "_mean"], ascending=False).head(max_households)
    chosen = chosen.drop(columns=["_n", "_mean"])
    chosen = chosen.loc[chosen.mean(axis=1).sort_values(ascending=False).index]  # highest first
    row_labels = attributes.loc[chosen.index, "label"] if attributes is not None else chosen.index
    chosen = chosen.dropna(axis=1, how="all")

    figure, axis = plt.subplots(figsize=(10, max(4.5, 0.2 * len(chosen) + 1.5)))
    upper = np.nanpercentile(chosen.to_numpy(dtype=float), 95)
    sns.heatmap(chosen.to_numpy(dtype=float), ax=axis, cmap="Blues", vmin=0, vmax=upper,
                xticklabels=_month_labels(chosen.columns), yticklabels=list(row_labels),
                cbar_kws={"label": f"Monthly value ({unit_label}), capped at 95th percentile"},
                linewidths=0.3, linecolor="white")
    axis.set_title(f"Household x month heatmap ({len(chosen)} households with the longest records)")
    axis.tick_params(axis="y", labelsize=7)
    axis.tick_params(axis="x", labelsize=8, rotation=45)
    figure.tight_layout()
    return figure


# --------------------------------------------------------------------------
# Boxplot
# --------------------------------------------------------------------------
def plot_boxplot_by_month(wide, unit_label="units", clip_quantile=0.995):
    """Boxplot per month; points beyond the whiskers are potential outliers.

    The y-axis is limited to the 99.5th percentile so the plot stays readable;
    the number of values hidden above the limit is written in the title.
    """
    if wide.empty:
        return _empty_figure("No months selected")
    long_table = wide.stack().rename("value").reset_index()
    long_table.columns = ["household_id", "month", "value"]
    long_table["label"] = long_table["month"].dt.strftime("%b %y")
    order = _month_labels(wide.columns)
    upper = float(long_table["value"].quantile(clip_quantile))
    hidden = int((long_table["value"] > upper).sum())

    figure, axis = plt.subplots(figsize=(10, 4.6))
    sns.boxplot(data=long_table, x="label", y="value", order=order, ax=axis,
                color=WATER_BLUES[3], fliersize=2.5, linewidth=1,
                flierprops={"markerfacecolor": ACCENT, "markeredgecolor": ACCENT})
    axis.set_ylim(0, upper * 1.05)
    axis.set_xlabel("")
    axis.set_ylabel(f"Monthly value ({unit_label})")
    axis.set_title(f"Spread of household values by month ({hidden} extreme values above the axis)")
    axis.tick_params(axis="x", rotation=45)
    figure.tight_layout()
    return figure


# --------------------------------------------------------------------------
# Distribution plot
# --------------------------------------------------------------------------
def plot_distribution(values, unit_label="units", log_scale=False, title="Distribution"):
    """Histogram with a smooth density curve."""
    clean = pd.Series(values).dropna()
    if clean.empty:
        return _empty_figure("No values to plot")
    figure, axis = plt.subplots(figsize=(8, 4.2))
    if log_scale:
        clean = clean[clean > 0]
    sns.histplot(clean, bins=40, kde=True, color=WATER_BLUES[1], ax=axis, log_scale=log_scale)
    axis.axvline(clean.median(), color=ACCENT, linestyle="--", linewidth=1.8,
                 label=f"Median {clean.median():.0f}")
    axis.set_xlabel(f"Value ({unit_label})" + (" - log scale" if log_scale else ""))
    axis.set_ylabel("Count")
    axis.set_title(title)
    axis.legend(frameon=False)
    figure.tight_layout()
    return figure


# --------------------------------------------------------------------------
# Household time series
# --------------------------------------------------------------------------
def plot_household_series(series, peer_summary, label, unit_label="units", flagged_months=None):
    """One household against the peer median and middle-50% band."""
    figure, axis = plt.subplots(figsize=(10, 4.2))
    peers = peer_summary.reindex(series.index)
    positions = np.arange(len(series))
    axis.fill_between(positions, peers["q1"], peers["q3"], color=WATER_BLUES[3], alpha=0.3,
                      label="Peers: middle 50%")
    axis.plot(positions, peers["median"], color=WATER_BLUES[2], linestyle="--", label="Peer median")
    axis.plot(positions, series.values, marker="o", color=WATER_BLUES[0], linewidth=2.4,
              label=label)
    if flagged_months is not None:
        flagged_positions = [i for i, m in enumerate(series.index) if m in set(flagged_months)]
        axis.scatter(flagged_positions, series.iloc[flagged_positions], s=110, color=ACCENT,
                     zorder=5, label="Above peer fence")
    axis.set_xticks(positions)
    axis.set_xticklabels(_month_labels(series.index), rotation=45, fontsize=8)
    axis.set_ylabel(f"Monthly value ({unit_label})")
    axis.set_title(f"{label}: monthly values compared with peers")
    axis.legend(frameon=False, ncol=2)
    figure.tight_layout()
    return figure


# --------------------------------------------------------------------------
# Forecasting charts
# --------------------------------------------------------------------------
def plot_actual_vs_predicted(monthly_comparison, model_names, unit_label="units"):
    """Average actual vs predicted value for each TEST month (never training months)."""
    figure, axis = plt.subplots(figsize=(10, 4.4))
    positions = np.arange(len(monthly_comparison))
    axis.plot(positions, monthly_comparison["actual"], marker="o", color=WATER_BLUES[0],
              linewidth=3, label="Actual")
    palette = [ACCENT, WATER_BLUES[2], "#6C757D", "#2A9D8F"]
    for color, name in zip(palette, model_names):
        axis.plot(positions, monthly_comparison[name], marker="s", linestyle="--",
                  color=color, linewidth=2, label=name)
    axis.set_xticks(positions)
    axis.set_xticklabels([f"{label}\n(n={count})" for label, count in
                          zip(_month_labels(monthly_comparison.index),
                              monthly_comparison["households"])], fontsize=9)
    axis.set_ylabel(f"Average monthly value ({unit_label})")
    axis.set_title("Test period: actual vs predicted (average over households)")
    axis.legend(frameon=False, fontsize=8)
    figure.tight_layout()
    return figure


def plot_prediction_scatter(test_samples, model_name, unit_label="units"):
    """Household-level actual vs predicted values (diagonal = perfect prediction)."""
    figure, axis = plt.subplots(figsize=(5.6, 5.2))
    limit = float(test_samples["actual"].quantile(0.99))
    axis.scatter(test_samples["actual"], test_samples[model_name], s=10, alpha=0.35,
                 color=WATER_BLUES[1])
    axis.plot([0, limit], [0, limit], color=ACCENT, linestyle="--", label="Perfect prediction")
    axis.set_xlim(0, limit)
    axis.set_ylim(0, limit)
    axis.set_xlabel(f"Actual ({unit_label})")
    axis.set_ylabel(f"Predicted ({unit_label})")
    axis.set_title(f"{model_name}\n(axes cut at the 99th percentile)", fontsize=10)
    axis.legend(frameon=False)
    figure.tight_layout()
    return figure


def plot_metric_comparison(metrics, metric="MAE", unit_label="units"):
    """Bar chart comparing the models on one error metric (lower is better)."""
    figure, axis = plt.subplots(figsize=(6.2, 3.6))
    ordered = metrics[metric].sort_values()
    axis.barh(ordered.index, ordered.values,
              color=[WATER_BLUES[0] if i == 0 else WATER_BLUES[3] for i in range(len(ordered))])
    axis.invert_yaxis()
    axis.set_xlabel(f"{metric} (lower is better)")
    axis.set_title(f"Model comparison - {metric}")
    figure.tight_layout()
    return figure


def plot_future_forecast(history_mean, forecast_mean, unit_label="units"):
    """Recent average (solid) followed by the forecast average (dashed)."""
    figure, axis = plt.subplots(figsize=(8.5, 3.8))
    history_positions = np.arange(len(history_mean))
    axis.plot(history_positions, history_mean.values, marker="o", color=WATER_BLUES[0],
              linewidth=2.4, label="Recorded average")
    forecast_positions = np.arange(len(history_mean) - 1, len(history_mean) + len(forecast_mean))
    connected = np.concatenate([[history_mean.values[-1]], forecast_mean.values])
    axis.plot(forecast_positions, connected, marker="s", linestyle="--", color=ACCENT,
              linewidth=2.2, label="Forecast (uncertain)")
    labels = _month_labels(history_mean.index) + _month_labels(forecast_mean.index)
    axis.set_xticks(np.arange(len(labels)))
    axis.set_xticklabels(labels, rotation=45, fontsize=8)
    axis.set_ylabel(f"Average monthly value ({unit_label})")
    axis.set_title("Recent months and short-term forecast")
    axis.legend(frameon=False)
    figure.tight_layout()
    return figure


def plot_coverage(households_per_month):
    """How many households have a value in each month (data coverage)."""
    figure, axis = plt.subplots(figsize=(10, 3.6))
    axis.bar(_month_labels(households_per_month.index), households_per_month.values,
             color=WATER_BLUES[2])
    axis.set_ylabel("Households with a value")
    axis.set_title("Data coverage: monthly values exist for few households outside Feb 2019 - Jan 2020")
    axis.tick_params(axis="x", rotation=45)
    figure.tight_layout()
    return figure
