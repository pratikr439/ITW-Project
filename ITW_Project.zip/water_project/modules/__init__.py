"""Reusable modules for the Smart Water Consumption Monitoring project."""
