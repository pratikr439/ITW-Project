"""
analysis.py
-----------
Statistical analysis and anomaly detection on the household x month table.

IT Workshop topics demonstrated here:
  * Module II : NumPy arrays and maths, Pandas GroupBy-style aggregation,
                sorting, filtering, statistical analysis, missing values

All "anomaly" results are statistical flags only. A high value is NOT proof of
a leak or of wastage: it can come from a larger family, guests, a data-entry
error, a changed billing cycle, and so on.
"""

import warnings

import numpy as np
import pandas as pd


# --------------------------------------------------------------------------
# Aggregation
# --------------------------------------------------------------------------
def monthly_summary(wide):
    """Per-month statistics across households (mean, median, total, n)."""
    summary = pd.DataFrame({
        "households": wide.notna().sum(),
        "mean": wide.mean(),
        "median": wide.median(),
        "q1": wide.quantile(0.25),
        "q3": wide.quantile(0.75),
        "total": wide.sum(min_count=1),
        "max": wide.max(),
    })
    summary.index.name = "month"
    return summary


def household_summary(wide, attributes=None):
    """Per-household statistics over the recorded months."""
    stats = pd.DataFrame({
        "months_recorded": wide.notna().sum(axis=1),
        "mean": wide.mean(axis=1),
        "median": wide.median(axis=1),
        "max": wide.max(axis=1),
        "min": wide.min(axis=1),
        "std": wide.std(axis=1),
        "total": wide.sum(axis=1, min_count=1),
    })
    # Coefficient of variation: how unstable a household's usage is.
    stats["cv"] = stats["std"] / stats["mean"].replace(0, np.nan)
    if attributes is not None:
        stats = attributes.join(stats, how="right")
    stats.index.name = "household_id"
    return stats


def top_and_bottom(summary, n=10, column="mean"):
    """Return (highest n, lowest n) households by the chosen column."""
    ranked = summary.sort_values(column, ascending=False)
    return ranked.head(n), ranked.tail(n).sort_values(column)


def balanced_panel(wide, start_month, end_month):
    """Households that have a value in EVERY month of the period.

    Comparing monthly averages is only fair when the same households are in
    every month; otherwise a changing sample looks like a changing trend.
    """
    period = wide[[m for m in wide.columns if start_month <= m <= end_month]]
    return period.dropna(how="any")


def group_mean_by_attribute(summary, attribute):
    """Average household consumption grouped by e.g. zone (GroupBy example)."""
    if attribute not in summary.columns:
        return pd.DataFrame()
    grouped = summary.groupby(attribute)["mean"].agg(["count", "mean", "median"])
    return grouped.sort_index()


# --------------------------------------------------------------------------
# Anomaly detection
# --------------------------------------------------------------------------
def iqr_fences(values, multiplier=1.5):
    """Lower and upper Tukey fences for a 1-D collection of numbers."""
    array = np.asarray(values, dtype=float)
    array = array[~np.isnan(array)]
    if array.size == 0:
        return np.nan, np.nan
    q1, q3 = np.percentile(array, [25, 75])
    spread = q3 - q1
    return q1 - multiplier * spread, q3 + multiplier * spread


def modified_z_scores(wide):
    """Robust z-score of each value against the household's OWN history.

    Uses the median and the median absolute deviation (MAD), which are not
    pulled around by the very outlier we are looking for. When the MAD is zero
    (a household that pays the same amount every month) the mean absolute
    deviation is used instead; if that is also zero the score stays NaN.
    """
    values = wide.to_numpy(dtype=float)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=RuntimeWarning)  # all-NaN rows
        median = np.nanmedian(values, axis=1, keepdims=True)
        abs_dev = np.abs(values - median)
        mad = np.nanmedian(abs_dev, axis=1, keepdims=True)
        mean_abs_dev = np.nanmean(abs_dev, axis=1, keepdims=True)

    scale = np.where(mad > 0, 1.4826 * mad, 1.2533 * mean_abs_dev)
    scale = np.where(scale > 0, scale, np.nan)
    scores = (values - median) / scale
    return pd.DataFrame(scores, index=wide.index, columns=wide.columns)


def detect_anomalies(
    wide,
    attributes=None,
    iqr_multiplier=1.5,
    z_threshold=3.5,
    spike_ratio=3.0,
    consistent_quantile=0.90,
    consistent_share=0.60,
    spike_min_multiple=2.0,
    min_months=6,
    min_households_per_month=20,
):
    """Flag households with unusual consumption using four simple rules.

    Rules
      1. HIGH_AVERAGE : household average is above the IQR upper fence of all
                        household averages (compared with peers).
      2. PEER_OUTLIER : in at least one month the value is above that month's
                        IQR upper fence (compared with peers in the same month).
      3. OWN_SPIKE    : a month is a robust z-score outlier against the
                        household's own history, or it jumped to >= spike_ratio
                        times the previous month. To avoid flagging small changes, a z-score
                        spike must also be at least `spike_min_multiple` times the
                        household's median and exceed it by the median monthly value.
      4. CONSISTENTLY_HIGH : value is above the month's 90th percentile in at
                        least 60 % of the household's recorded months.

    Returns
      flagged : DataFrame (one row per flagged household with reasons)
      details : dict with the thresholds used and rule counts
    """
    # Only households with enough history can be judged fairly.
    history = wide.notna().sum(axis=1)
    candidates = wide[history >= min_months]
    if candidates.empty:
        return pd.DataFrame(), {"households_checked": 0}

    all_values = candidates.to_numpy(dtype=float)
    min_increase = float(np.nanmedian(all_values))  # data-driven "meaningful jump"

    # ---- Rule 1: household average vs peers --------------------------------
    household_mean = candidates.mean(axis=1)
    _, mean_upper_fence = iqr_fences(household_mean, iqr_multiplier)
    rule_high_average = household_mean > mean_upper_fence

    # ---- Rule 2: value vs peers of the same month --------------------------
    enough_peers = candidates.notna().sum() >= min_households_per_month
    month_upper_fence = candidates.apply(lambda col: iqr_fences(col, iqr_multiplier)[1])
    month_upper_fence[~enough_peers] = np.nan  # too few peers -> do not judge
    above_peer_fence = candidates.gt(month_upper_fence, axis=1)
    peer_outlier_months = above_peer_fence.sum(axis=1)
    rule_peer_outlier = peer_outlier_months >= 1

    # ---- Rule 3: spike against own history ---------------------------------
    z_table = modified_z_scores(candidates)
    median_of_household = candidates.median(axis=1)
    big_enough = (candidates.sub(median_of_household, axis=0) >= min_increase) & \
        candidates.ge(median_of_household * spike_min_multiple, axis=0)
    z_spike = z_table.gt(z_threshold) & big_enough

    previous_month = candidates.shift(1, axis=1)
    jump_ratio = candidates / previous_month.where(previous_month > 0)
    jump_amount = candidates - previous_month
    jump_spike = jump_ratio.ge(spike_ratio) & jump_amount.ge(min_increase)

    spike_table = z_spike | jump_spike
    rule_own_spike = spike_table.any(axis=1)

    # ---- Rule 4: consistently high ------------------------------------------
    month_high_cut = candidates.quantile(consistent_quantile)
    above_high_cut = candidates.gt(month_high_cut, axis=1)
    share_high = above_high_cut.sum(axis=1) / candidates.notna().sum(axis=1)
    rule_consistent = share_high >= consistent_share

    # ---- Combine ---------------------------------------------------------------
    rules = pd.DataFrame({
        "HIGH_AVERAGE": rule_high_average,
        "PEER_OUTLIER": rule_peer_outlier,
        "OWN_SPIKE": rule_own_spike,
        "CONSISTENTLY_HIGH": rule_consistent,
    })
    flagged_ids = rules.index[rules.any(axis=1)]

    rows = []
    peer_median_of_means = float(household_mean.median())
    for household_id in flagged_ids:  # loop to build a readable reason for each household
        series = candidates.loc[household_id]
        peak_month = series.idxmax()
        reasons = []
        if rules.at[household_id, "HIGH_AVERAGE"]:
            reasons.append(
                f"Average {series.mean():.0f} is above the peer upper fence "
                f"({mean_upper_fence:.0f}); peer median average is {peer_median_of_means:.0f}"
            )
        if rules.at[household_id, "PEER_OUTLIER"]:
            reasons.append(
                f"Above the peer IQR fence in {int(peer_outlier_months[household_id])} month(s)"
            )
        if rules.at[household_id, "OWN_SPIKE"]:
            spike_months = spike_table.loc[household_id]
            # Pick the strongest flagged month (by absolute value of the reading).
            spike_month = series.where(spike_months).idxmax()
            reasons.append(
                f"Spike in {pd.Timestamp(spike_month):%b %Y}: {series[spike_month]:.0f} "
                f"vs own median {median_of_household[household_id]:.0f}"
            )
        if rules.at[household_id, "CONSISTENTLY_HIGH"]:
            reasons.append(
                f"In the top {int((1 - consistent_quantile) * 100)}% of households in "
                f"{share_high[household_id] * 100:.0f}% of its months"
            )

        jump_row = jump_amount.loc[household_id]
        biggest_jump_month = jump_row.idxmax() if jump_row.notna().any() else None
        rows.append({
            "household_id": household_id,
            "months_recorded": int(series.notna().sum()),
            "average": float(series.mean()),
            "peak_value": float(series.max()),
            "peak_month": peak_month,
            "largest_month_jump": float(jump_amount.at[household_id, biggest_jump_month])
            if biggest_jump_month is not None else np.nan,
            "rules_triggered": int(rules.loc[household_id].sum()),
            "rule_names": ", ".join(rules.columns[rules.loc[household_id]]),
            "reasons": " | ".join(reasons),
            "status": "Potential anomaly (not a confirmed leak or wastage)",
        })

    flagged = pd.DataFrame(rows)
    if not flagged.empty:
        flagged = flagged.sort_values(["rules_triggered", "average"], ascending=False)
        if attributes is not None:
            flagged = flagged.merge(
                attributes[["label"] + [c for c in ("ward", "zone", "household_size")
                                        if c in attributes.columns]],
                left_on="household_id", right_index=True, how="left",
            )
        flagged = flagged.reset_index(drop=True)

    details = {
        "households_checked": int(len(candidates)),
        "households_flagged": int(len(flagged)),
        "average_upper_fence": float(mean_upper_fence),
        "min_meaningful_increase": min_increase,
        "rule_counts": {name: int(rules[name].sum()) for name in rules.columns},
        "above_peer_fence_matrix": above_peer_fence,
        "month_upper_fence": month_upper_fence,
        "z_scores": z_table,
    }
    return flagged, details
